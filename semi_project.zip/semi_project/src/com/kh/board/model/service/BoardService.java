package com.kh.board.model.service;

import java.sql.Connection;
import java.util.ArrayList;

import com.kh.board.model.dao.BoardDao;
import com.kh.board.model.vo.Book;
import com.kh.board.model.vo.Cover;
import com.kh.common.JDBCTemplate;

public class BoardService {

	public ArrayList<Book> selectBookList() {
		Connection conn = JDBCTemplate.getConnection();
		
		ArrayList<Book> list = new BoardDao().selectBookList(conn);
		
		JDBCTemplate.close(conn);
		
		return list;
	}

}
