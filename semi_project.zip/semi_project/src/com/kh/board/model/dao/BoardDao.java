package com.kh.board.model.dao;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Properties;

import com.kh.board.model.vo.Book;
import com.kh.board.model.vo.Cover;
import com.kh.common.JDBCTemplate;

public class BoardDao {

	private Properties prop = new Properties();
	
	public BoardDao() {
		String filePath = BoardDao.class.getResource("/db/sql/board-mapper.xml").getPath();
	
		try {
			prop.loadFromXML(new FileInputStream(filePath));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
	}

	public ArrayList<Book> selectBookList(Connection conn) {
		ArrayList<Book> list = new ArrayList<>();
		PreparedStatement pstmt = null;
		ResultSet rset = null;
		String sql = prop.getProperty("selectBookList");
		
		try {
			pstmt=conn.prepareStatement(sql);
			rset=pstmt.executeQuery();
			while(rset.next()) {
				
				list.add(new Book(rset.getInt("BOOK_NO"),
								  rset.getString("GENRE_NAME"),
								  rset.getString("BOOK_TITLE"),
								  rset.getString("AUTHOR"),
								  rset.getString("BOOK_INFO"),
								  rset.getInt("RENT_COUNT"),
								  rset.getDate("CREATE_BOOK"),
								  rset.getString("STATUS"),
								  rset.getString("FILE_PATH"),
								  rset.getString("ORIGIN_NAME"))
						);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			JDBCTemplate.close(rset);
			JDBCTemplate.close(pstmt);
		}
		return list;
	}


}
